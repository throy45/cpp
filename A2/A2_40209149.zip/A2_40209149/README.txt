Assignment 2 - Due June 15th, 2023
Thomas Roy - 40209149
Special instructions:
- None.
Extra features:
- None.
Known bugs:
- None.
Notes:
- Snake case was preferred to camelCase, even though the assignmnet description showed a mix of both.