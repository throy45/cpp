Assignment 3 - Due July 9th, 2023
Thomas Roy - 40209149
Special instructions:
- None.
Extra features:
- None.
Known bugs:
- When printing matrices, the spacing might be uneven for large numbers. Also, only 2 digits of precision are shown (but the program keeps tracks of all digits up to the double capacity).
Notes:
- See comments in the code if needed.